package com.izsuku.lengthconverter

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

class MainActivity : Activity() {
    private data class UnitDef(val name: String, val symbol: String, val metres: Double)
    private val units = listOf(
        UnitDef("Kilometer", "km", 1000.0),
        UnitDef("Meter", "m", 1.0),
        UnitDef("Centimeter", "cm", 0.01),
        UnitDef("Millimeter", "mm", 0.001),
        UnitDef("Micrometer", "µm", 1e-6),
        UnitDef("Nanometer", "nm", 1e-9),
        UnitDef("Mile", "mi", 1609.344),
        UnitDef("Yard", "yd", 0.9144),
        UnitDef("Foot", "ft", 0.3048),
        UnitDef("Inch", "in", 0.0254),
        UnitDef("Nautical mile", "nmi", 1852.0),
        UnitDef("Decimeter", "dm", 0.1),
        UnitDef("Hectometer", "hm", 100.0)
    )
    private val fields = mutableListOf<EditText>()
    private var updating = false
    private lateinit var root: LinearLayout
    private val bg = Color.rgb(12, 16, 26)
    private val panel = Color.rgb(25, 31, 45)
    private val blue = Color.rgb(43, 112, 255)
    private val white = Color.rgb(245, 247, 252)
    private val muted = Color.rgb(164, 174, 193)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildUi()
    }

    private fun rounded(color: Int, stroke: Int = Color.TRANSPARENT, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius * resources.displayMetrics.density; if (stroke != Color.TRANSPARENT) setStroke((1.3f * resources.displayMetrics.density).toInt(), stroke) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(12), dp(18), dp(12)) }
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val heading = TextView(this).apply { text = "Length Converter"; setTextColor(white); textSize = 27f; typeface = Typeface.DEFAULT_BOLD }
        content.addView(heading)
        content.addView(TextView(this).apply { text = "Convert all length units instantly"; setTextColor(muted); textSize = 14f; setPadding(0, dp(4), 0, dp(18)) })
        val note = TextView(this).apply {
            text = "Enter a value in any unit. Every other unit updates automatically."
            setTextColor(muted); textSize = 13f; setPadding(dp(13), dp(12), dp(13), dp(12)); background = rounded(panel, Color.rgb(48, 59, 79))
        }
        content.addView(note, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        units.forEachIndexed { index, unit ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(13), dp(7), dp(9), dp(7)); background = rounded(panel, if (index == 0) blue else Color.rgb(48, 57, 73), 15f)
            }
            val label = TextView(this).apply {
                text = "${unit.name}\n(${unit.symbol})"; setTextColor(white); textSize = 14f
            }
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1.0f))
            val edit = EditText(this).apply {
                setTextColor(white); setHintTextColor(Color.rgb(112, 123, 143)); textSize = 16f
                gravity = Gravity.END or Gravity.CENTER_VERTICAL; singleLine = true
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
                hint = "0"; setPadding(dp(8), dp(7), dp(8), dp(7)); background = rounded(Color.rgb(14, 19, 30), Color.rgb(54, 65, 85), 11f)
                setSelectAllOnFocus(false)
            }
            fields.add(edit)
            row.addView(edit, LinearLayout.LayoutParams(dp(150), dp(46)))
            content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            edit.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (!updating) convertFrom(index, s?.toString().orEmpty())
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(7), 0, 0) }
        val clear = Button(this).apply { text = "Clear all"; isAllCaps = false; setTextColor(white); background = rounded(Color.rgb(55, 64, 82), 0, 22f); setOnClickListener { clearAll() } }
        val about = Button(this).apply { text = "About"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(blue, 0, 22f); setOnClickListener { showAbout() } }
        buttons.addView(clear, LinearLayout.LayoutParams(0, dp(50), 1f).apply { rightMargin = dp(6) })
        buttons.addView(about, LinearLayout.LayoutParams(0, dp(50), 1f).apply { leftMargin = dp(6) })
        content.addView(buttons)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun convertFrom(sourceIndex: Int, raw: String) {
        updating = true
        try {
            if (raw.isBlank() || raw == "." || raw == "-" || raw == "-.") {
                fields.forEachIndexed { i, field -> if (i != sourceIndex) field.setText("") }
                return
            }
            val value = raw.toBigDecimalOrNull() ?: return
            val metres = value.multiply(BigDecimal.valueOf(units[sourceIndex].metres), MathContext.DECIMAL128)
            fields.forEachIndexed { i, field ->
                if (i == sourceIndex) return@forEachIndexed
                val converted = metres.divide(BigDecimal.valueOf(units[i].metres), MathContext.DECIMAL128)
                field.setText(format(converted))
            }
        } finally { updating = false }
    }

    private fun format(value: BigDecimal): String {
        if (value.compareTo(BigDecimal.ZERO) == 0) return "0"
        val stripped = value.stripTrailingZeros()
        return if (stripped.precision() > 12 || stripped.scale() < -6 || stripped.scale() > 9) {
            stripped.round(MathContext(10, RoundingMode.HALF_UP)).stripTrailingZeros().toString()
        } else stripped.toPlainString()
    }

    private fun clearAll() {
        updating = true
        fields.forEach { it.setText("") }
        updating = false
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(root.windowToken, 0)
        root.clearFocus()
    }

    private fun showAbout() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Length Converter")
            .setMessage("A simple offline length calculator. Type into any unit field to convert all supported units instantly.\n\nConversions use standard metric and international length definitions.")
            .setPositiveButton("Got it", null).show()
    }
}
