# Length Converter (Android)

A native Kotlin Android length converter. Type a value into any unit field and all other fields update instantly. It works offline and requests no internet permission.

## Units

Kilometer (km), hectometer (hm), decimeter (dm), meter (m), centimeter (cm), millimeter (mm), micrometer (µm), nanometer (nm), mile (mi), yard (yd), foot (ft), inch (in), and nautical mile (nmi).

## Open-source license

This project is licensed under the MIT License. See [LICENSE](LICENSE).

## Build and install on an Android phone

1. Install Android Studio on your computer: https://developer.android.com/studio
2. Extract this ZIP file.
3. In Android Studio, choose **Open** and select the `LengthConverter` folder (the folder containing `settings.gradle.kts`).
4. Wait for Gradle sync. If prompted, install Android SDK Platform 35.
5. To run directly on a connected Android phone: enable Developer options and USB debugging on the phone, connect it by USB, approve the debugging prompt, select the phone in Android Studio, and press **Run**.
6. To create an APK file: choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio will show a notification with the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to the phone, open it, and allow your file manager/browser to install unknown apps if Android asks.

The debug APK is suitable for personal testing. Create a signed release APK for wider distribution.

Package: `com.izsuku.lengthconverter`  
Minimum Android: 6.0 (API 23)  
Target SDK: 35
